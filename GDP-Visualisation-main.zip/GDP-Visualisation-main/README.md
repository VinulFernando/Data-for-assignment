# GDP-Visualisation

This is an interactive visualisation of the various factors that affect the GDP of a country and vice-versa. It was created using Vega-Lite and d3.

The visualisation can be viewed at the following link:
https://mazm0002.github.io/GDP-Visualisation/

![alt text](https://raw.githubusercontent.com/mazm0002/GDP-Visualisation/main/gdp-viz.JPG)

